import React, { Component } from 'react';
import { Card } from 'react-bootstrap';
import { connect } from 'react-redux';
import io from 'socket.io-client';
import * as actionCreators from '../../actions';

@connect(null, actionCreators)
class ChatView extends Component {
  render() {
    const socket = io();
    socket.on('newMessage', (data) => {
      console.log('This is a Data: ', data);
    });
    return (
      <Card style={{ width: '40rem', height: '30rem' }}>
        <Card.Body> Here will be messages </Card.Body>
      </Card>
    );
  }
}

export default ChatView;
