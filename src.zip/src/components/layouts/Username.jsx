// import React, { Component } from 'react';

// class Username extends Component {
//   render() {
//     console.log('we are in Username: ', this.props);
//     const { context2 } = this.props;
//     return (
//       <context2.Consumer>
//         {
//           username => (
//             <h1>{username}</h1>
//           )
//           }
//       </context2.Consumer>
//     );
//   }
// }

// export default Username;
